package com.khit.recruit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Final2teamApplicationTests {

	@Test
	void contextLoads() {
	}

}
